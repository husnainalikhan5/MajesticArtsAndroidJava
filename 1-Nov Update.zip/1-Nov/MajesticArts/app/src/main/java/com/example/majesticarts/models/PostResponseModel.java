package com.example.majesticarts.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PostResponseModel {
    @SerializedName("status")
    private int status;
    @SerializedName("message")
    private String message;
    @SerializedName("data")
    private List<PostDataModel> data;

    public PostResponseModel() {
    }

    public PostResponseModel(int status, String message, List<PostDataModel> data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<PostDataModel> getData() {
        return data;
    }

    public void setData(List<PostDataModel> data) {
        this.data = data;
    }
}
