package com.example.majesticarts.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bumptech.glide.Glide;
import com.example.majesticarts.R;
import com.example.majesticarts.models.SingleItemImagesModel;


import java.util.List;

public class SlidingImagesAdapter extends PagerAdapter {
    List<SingleItemImagesModel> listItems;
    Context context;

    public SlidingImagesAdapter(List<SingleItemImagesModel> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }


    @Override
    public int getCount() {
        return listItems.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        View view = LayoutInflater.from(context).inflate(R.layout.layout_single_image, null );
        SingleItemImagesModel listItem = listItems.get(position);
        ImageView sliderImage = (ImageView) view.findViewById(R.id.img_Collection);
        Glide.with(view)
                .load(listItem.getSliderImage())
                .fitCenter()
                .into(sliderImage);
        container.addView(view,0);
        return  view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        //remove object from conatiner
        container.removeView((View) object);
    }

    @Override
    public int getItemPosition(@NonNull Object object) {

        return super.getItemPosition(object);
    }
}
