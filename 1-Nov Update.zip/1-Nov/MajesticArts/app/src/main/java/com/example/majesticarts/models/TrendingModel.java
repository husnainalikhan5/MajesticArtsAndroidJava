package com.example.majesticarts.models;

public class TrendingModel {
    public int trending_Image;
    public String trending_Detail;
    public  String trending_Courtesy;

    public TrendingModel() {
    }

    public TrendingModel(int trending_Image, String trending_Detail, String trending_Courtesy) {
        this.trending_Image = trending_Image;
        this.trending_Detail = trending_Detail;
        this.trending_Courtesy = trending_Courtesy;
    }

    public int getTrending_Image() {
        return trending_Image;
    }

    public void setTrending_Image(int trending_Image) {
        this.trending_Image = trending_Image;
    }

    public String getTrending_Detail() {
        return trending_Detail;
    }

    public void setTrending_Detail(String trending_Detail) {
        this.trending_Detail = trending_Detail;
    }

    public String getTrending_Courtesy() {
        return trending_Courtesy;
    }

    public void setTrending_Courtesy(String trending_Courtesy) {
        this.trending_Courtesy = trending_Courtesy;
    }
}
