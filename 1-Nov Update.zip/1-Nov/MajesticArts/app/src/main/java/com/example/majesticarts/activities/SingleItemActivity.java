package com.example.majesticarts.activities;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.majesticarts.R;
import com.example.majesticarts.adapters.SlidingImagesAdapter;
import com.example.majesticarts.models.AuthResponseModel;
import com.example.majesticarts.models.SingleItemImagesModel;
import com.example.majesticarts.models.AddFavouriteResponseModel;
import com.example.majesticarts.network.GetDataService;
import com.example.majesticarts.network.RetrofitClientInstance;
import com.example.majesticarts.utilities.Utilities;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SingleItemActivity extends AppCompatActivity {
    private ViewPager ViewPager_slidingImage;
    private SlidingImagesAdapter adapter;
    TextView text_CollectionName, text_PostDetail;
    GetDataService service;
    ProgressDialog progressDialog;
    String postId, postName, postDetail,favourite_status, userId, userFName, userLName, userEmail, userPhone;
    ArrayList<String> imagesList = new ArrayList<String>();
    List<SingleItemImagesModel> imagesModelList;
    int NUM_PAGES = 0;
    int currentPage = 0;
    Timer timer;
    ImageView star_ic, next_Btn, back_Btn, back_ic;
    String fav_status = "true";
    Button btn_GetQuotation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_item);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setTopStatusBarColor();
        }
        back_ic = findViewById(R.id.back_ic);
        back_ic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        progressDialog = new ProgressDialog(SingleItemActivity.this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();
        service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        star_ic = findViewById(R.id.star_ic);
        userId = String.valueOf(Utilities.getInt(getApplicationContext(), "userId"));
        init();

        Toast.makeText(getApplicationContext(), "Images Length " + imagesList.size(), Toast.LENGTH_LONG).show();

        text_CollectionName = findViewById(R.id.text_CollectionName);
        text_PostDetail = findViewById(R.id.text_PostDetail);
        text_CollectionName.setText(postName);
        text_PostDetail.setText(postDetail);
        ViewPager_slidingImage = findViewById(R.id.ViewPager_slidingImage);
        next_Btn = findViewById(R.id.next_Btn);
        back_Btn = findViewById(R.id.back_Btn);

        showSlidingImages(ViewPager_slidingImage);
        timer = new Timer();
        timer.scheduleAtFixedRate(new MyTimerTask(),4000,4000);


        next_Btn.setOnClickListener(v -> ViewPager_slidingImage.setCurrentItem(ViewPager_slidingImage.getCurrentItem() + 1));

        back_Btn.setOnClickListener(v -> {
            if (currentPage >= 1)
            {
                ViewPager_slidingImage.setCurrentItem(ViewPager_slidingImage.getCurrentItem() - 1);
            }
        });

        checkForFavouriteStatus();

        star_ic.setOnClickListener(v -> {
            addForFavourites(userId, postId);
            if (fav_status.equals("no")){
                star_ic.setImageResource(R.drawable.filled_star);
                fav_status = "yes";
            }else {
                star_ic.setImageResource(R.drawable.star);
                fav_status = "no";
            }
        });


        // Add Quotation
        btn_GetQuotation   = findViewById(R.id.btn_GetQuotation);
        btn_GetQuotation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("We are send your quotation");
                progressDialog.show();
                if (userFName.isEmpty() || userLName.isEmpty() || userEmail.isEmpty() || userPhone.isEmpty() || postId.isEmpty() || postName.isEmpty()){
                    Snackbar.make(v, "There is Some Thing Missing", Snackbar.LENGTH_LONG).show();
                }
                else {
                    sendQuotationRequest(userFName, userLName, userEmail, userPhone, postId, postName);
                }
            }
        });
    }


    private void addForFavourites(String user_id, String postId) {

        Call<AddFavouriteResponseModel> call = service.add_Favourites(user_id, postId);
        call.enqueue(new Callback<AddFavouriteResponseModel>() {
            @Override
            public void onResponse(Call<AddFavouriteResponseModel> call, Response<AddFavouriteResponseModel> response) {
                progressDialog.dismiss();
                assert response.body() != null;
                String message  = response.body().getMessage();
                if (!message.isEmpty() && message.equals("Record Add Successfully!")){
                    Toast.makeText(getApplicationContext(),"Status ******* " + message, Toast.LENGTH_LONG).show();

                }
                else if (!message.isEmpty() && message.equals("Remove from favroute list!")){
                    Toast.makeText(getApplicationContext(), response.body().getMessage() , Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<AddFavouriteResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
            }
        });
    }


    public void showSlidingImages(ViewPager viewPager){
        imagesModelList = new ArrayList<>();
        for (int i = 0; i <= imagesList.size() - 1; i++) {
            SingleItemImagesModel listItem = new SingleItemImagesModel();
            listItem.setSliderImage(imagesList.get(i));
            imagesModelList.add(listItem);
        }
        progressDialog.dismiss();
        adapter = new SlidingImagesAdapter(imagesModelList, this);
        viewPager.setAdapter(adapter);
    }

    public class MyTimerTask extends TimerTask {
        @Override
        public void run() {
            // here you check the value of getActivity() and break up if needed
            if(SingleItemActivity.this == null)
                return;
            SingleItemActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
//
                    if (currentPage == NUM_PAGES-1) {
                        currentPage = 0;
                    }
                    else {
                        currentPage++;
                    }
                    ViewPager_slidingImage.setCurrentItem(currentPage, true);
                }
            });
        }
    }


    public void init(){
        postId = String.valueOf(getIntent().getIntExtra("postId", 0));
        postName = getIntent().getStringExtra("postName");
        postDetail = getIntent().getStringExtra("postDetail");
        favourite_status = getIntent().getStringExtra("favourite_status");
        fav_status = favourite_status;
        userFName = Utilities.getString(SingleItemActivity.this, "userFName");
        userLName = Utilities.getString(SingleItemActivity.this,"userLName");
        userEmail = Utilities.getString(SingleItemActivity.this,"userEmail");
        userPhone = Utilities.getString(SingleItemActivity.this,"userPhone");

        Toast.makeText(getApplicationContext(), "favourite_status" + favourite_status, Toast.LENGTH_LONG).show();
        String image1 = getIntent().getStringExtra("image1");
        String image2 = getIntent().getStringExtra("image2");
        String image3 = getIntent().getStringExtra("image3");
        String image4 = getIntent().getStringExtra("image4");
        String image5 = getIntent().getStringExtra("image5");

        if (image1 !=null && !image1.isEmpty()){
            imagesList.add(image1);
        }
        if (image2 != null && !image2.isEmpty()){
            imagesList.add(image2);
        }
        if (image3 != null && !image3.isEmpty()){
            imagesList.add(image3);
        }
        if (image4 != null && !image4.isEmpty() ){
            imagesList.add(image4);
        }
        if (image5 != null && !image5.isEmpty()){
            imagesList.add(image5);
        }
    }

    public void checkForFavouriteStatus(){
        if (favourite_status !=null && favourite_status.equals("yes")){
            star_ic.setImageResource(R.drawable.filled_star);
        }
        else {
            star_ic.setImageResource(R.drawable.star);
        }
    }

    private void sendQuotationRequest(String userFName, String userLName, String userEmail, String userPhone, String postId, String postName){

        Call<AuthResponseModel> call = service.getQuotation( userFName,userLName, userEmail, userPhone, postId, postName);
        call.enqueue(new Callback<AuthResponseModel>() {
            @Override
            public void onResponse(Call<AuthResponseModel> call, Response<AuthResponseModel> response) {
                progressDialog.dismiss();
                assert response.body() != null;
                int status  = response.body().getStatus();
                if (!String.valueOf(status).isEmpty() && status == 200){
                    Toast.makeText(SingleItemActivity.this, response.body().getMessage() , Toast.LENGTH_LONG).show();
                }
                else if (!String.valueOf(status).isEmpty() && status == 400){
                    Toast.makeText(SingleItemActivity.this, response.body().getMessage()  + "Failed", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<AuthResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(SingleItemActivity.this, t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void setTopStatusBarColor(){
        Window window = SingleItemActivity.this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(SingleItemActivity.this,R.color.color_cloud_brust));
    }
}