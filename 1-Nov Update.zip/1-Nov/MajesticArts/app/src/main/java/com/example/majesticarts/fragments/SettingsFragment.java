package com.example.majesticarts.fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.majesticarts.R;
import com.example.majesticarts.models.AuthResponseModel;
import com.example.majesticarts.models.UpdateMobileNumberModel;
import com.example.majesticarts.network.GetDataService;
import com.example.majesticarts.network.RetrofitClientInstance;
import com.example.majesticarts.utilities.Utilities;
import com.google.android.material.snackbar.Snackbar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SettingsFragment extends Fragment {

    EditText edit_NewPassword, edit_RetypeNewPassword, edit_addNewNumber;
    Button btn_SubmitPhone, btn_SubmitPassword;
    GetDataService service;
    ProgressDialog progressDialog;
    RelativeLayout layout_Root;
    String userId;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view =  inflater.inflate(R.layout.fragment_settings, container, false);

        // Services and getUserId
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Updating ....");
        service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        userId = String.valueOf(Utilities.getInt(getContext(), "userId"));

        layout_Root = view.findViewById(R.id.layout_Root);
        edit_NewPassword = view.findViewById(R.id.edit_NewPassword);
        edit_RetypeNewPassword = view.findViewById(R.id.edit_RetypeNewPassword);
        edit_addNewNumber = view.findViewById(R.id.edit_addNewNumber);
        btn_SubmitPhone = view.findViewById(R.id.btn_SubmitPhone);
        btn_SubmitPassword = view.findViewById(R.id.btn_SubmitPassword);

        btn_SubmitPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show();
                String userPassword = edit_NewPassword.getText().toString();
                String userConfirmPassword = edit_RetypeNewPassword.getText().toString();
                Utilities.hideKeyboard(v, getContext());
                if (userPassword.isEmpty() || userConfirmPassword.isEmpty())
                {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Please Add the missing fields", Toast.LENGTH_LONG).show();
                }
                else {
                    resetPasswordRequest(userPassword, userConfirmPassword);
                }
            }
        });
        btn_SubmitPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show();
                String userMobileNumber = edit_addNewNumber.getText().toString();
                Utilities.hideKeyboard(v, getContext());
                if (userMobileNumber.isEmpty())
                {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Please Add the missing fields", Toast.LENGTH_LONG).show();
                }
                else {
                    updateMobileNumber(userMobileNumber);
                }
            }
        });




        return view;
    }

    private void resetPasswordRequest(String userPassword, String userConfirmPassword) {

        Call<AuthResponseModel> call = service.resetUserPassword( userId, userPassword, userConfirmPassword);

        call.enqueue(new Callback<AuthResponseModel>() {
            @Override
            public void onResponse(Call<AuthResponseModel> call, Response<AuthResponseModel> response) {
                progressDialog.dismiss();
                assert response.body() != null;
                int status  = response.body().getStatus();
                if (!String.valueOf(status).isEmpty() && status == 200){
                    Snackbar.make(layout_Root, response.body().getMessage(), Snackbar.LENGTH_LONG).show();
                }
                else if (!String.valueOf(status).isEmpty() && status == 400){
                    Snackbar.make(layout_Root, response.body().getMessage() + "Failed", Snackbar.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<AuthResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void updateMobileNumber(String userMobileNumber) {

        Call<UpdateMobileNumberModel> call = service.updateMobileNumber( userId, userMobileNumber);

        call.enqueue(new Callback<UpdateMobileNumberModel>() {
            @Override
            public void onResponse(Call<UpdateMobileNumberModel> call, Response<UpdateMobileNumberModel> response) {
                progressDialog.dismiss();
                assert response.body() != null;
                int status  = response.body().getStatus();
                if (!String.valueOf(status).isEmpty() && status == 200){
                    Snackbar.make(layout_Root, response.body().getMessage(), Snackbar.LENGTH_LONG).show();
                }
                else if (!String.valueOf(status).isEmpty() && status == 400){
                    Snackbar.make(layout_Root, response.body().getMessage() + "Failed", Snackbar.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<UpdateMobileNumberModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
            }
        });
    }
}