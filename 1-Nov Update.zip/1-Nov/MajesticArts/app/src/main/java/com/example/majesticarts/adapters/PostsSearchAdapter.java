package com.example.majesticarts.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.majesticarts.R;
import com.example.majesticarts.activities.SingleItemActivity;
import com.example.majesticarts.models.PostDataModel;

import java.util.ArrayList;
import java.util.List;

public class PostsSearchAdapter extends RecyclerView.Adapter<PostsSearchAdapter.ViewHolder> implements Filterable {

    List<PostDataModel> listItems;
    List<PostDataModel> listItemsFiltered;
    Context context;

    public PostsSearchAdapter() {
    }

    public void setSearchItems(Context context, final List<PostDataModel> listItems) {
        this.context = context;
        if (this.listItems == null) {
            this.listItems = listItems;
            this.listItemsFiltered = listItems;
            notifyItemChanged(0, listItemsFiltered.size());
        } else {
            final DiffUtil.DiffResult result = DiffUtil.calculateDiff(new DiffUtil.Callback() {
                @Override
                public int getOldListSize() {
                    return PostsSearchAdapter.this.listItems.size();
                }

                @Override
                public int getNewListSize() {
                    return listItems.size();
                }

                @Override
                public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                    return PostsSearchAdapter.this.listItems.get(oldItemPosition).getTitle() == listItems.get(newItemPosition).getTitle();
                }

                @Override
                public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {

                    PostDataModel newList = PostsSearchAdapter.this.listItems.get(oldItemPosition);

                    PostDataModel oldList = listItems.get(newItemPosition);

                    return newList.getTitle() == oldList.getTitle();
                }
            });
            this.listItems = listItems;
            this.listItemsFiltered = listItems;
            result.dispatchUpdatesTo(this);
        }
    }

    public PostsSearchAdapter(List<PostDataModel> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.single_trending_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        holder.text_Courtesy.setText(listItemsFiltered.get(position).getSubtitle());
        holder.text_Detail.setText(listItemsFiltered.get(position).getTitle());



        Glide.with(holder.itemView)
                .load(listItemsFiltered.get(position).getCaption_image())
                .fitCenter()
                .into(holder.trending_Image);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(holder.itemView.getContext(), SingleItemActivity.class);
                mainIntent.putExtra("postId", listItemsFiltered.get(position).getId());
                mainIntent.putExtra("postName",  listItemsFiltered.get(position).getTitle());
                mainIntent.putExtra("postDetail",  listItemsFiltered.get(position).getDescription());
                mainIntent.putExtra("image1", listItemsFiltered.get(position).getImage1());
                mainIntent.putExtra("image2", listItemsFiltered.get(position).getImage2());
                mainIntent.putExtra("image3", listItemsFiltered.get(position).getImage3());
                mainIntent.putExtra("image4", listItemsFiltered.get(position).getImage4());
                mainIntent.putExtra("image5", listItemsFiltered.get(position).getImage5());
                mainIntent.putExtra("favourite_status", listItemsFiltered.get(position).getFavrte_routine());
                holder.itemView.getContext().startActivity(mainIntent);
            }
        });
    }


    @Override
    public int getItemCount() {

        if (listItems != null) {
            return listItemsFiltered.size();
        } else {
            return 0;
        }
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    listItemsFiltered = listItems;
                } else {
                    List<PostDataModel> filteredList = new ArrayList<>();
                    for (PostDataModel post : listItems) {
                        if (post.getTitle().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(post);
                        }
                    }
                    listItemsFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = listItemsFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults filterResults) {
                listItemsFiltered = (ArrayList<PostDataModel>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView trending_Image;
        public TextView text_Detail, text_Courtesy;

        public ViewHolder(@NonNull View view) {
            super(view);

            trending_Image = view.findViewById(R.id.trending_Image);
            text_Detail = view.findViewById(R.id.trending_Detail);
            text_Courtesy = view.findViewById(R.id.trending_courtesy);
        }
    }


}