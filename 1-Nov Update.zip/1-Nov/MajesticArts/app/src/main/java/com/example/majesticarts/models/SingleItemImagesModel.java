package com.example.majesticarts.models;

import com.google.gson.annotations.SerializedName;

public class SingleItemImagesModel {

    private String sliderImage;

    public SingleItemImagesModel() {
    }

    public SingleItemImagesModel(String sliderImage) {
        this.sliderImage = sliderImage;
    }

    public String getSliderImage() {
        return sliderImage;
    }

    public void setSliderImage(String sliderImage) {
        this.sliderImage = sliderImage;
    }
}
