package com.example.majesticarts.models;

public class ForYouArtCollectionModel {
    public int artCollectionImage;
    public String artCollectionName;

    public ForYouArtCollectionModel() {
    }

    public ForYouArtCollectionModel(int artCollectionImage, String artCollectionName) {
        this.artCollectionImage = artCollectionImage;
        this.artCollectionName = artCollectionName;
    }

    public int getArtCollectionImage() {
        return artCollectionImage;
    }

    public void setArtCollectionImage(int artCollectionImage) {
        this.artCollectionImage = artCollectionImage;
    }

    public String getArtCollectionName() {
        return artCollectionName;
    }

    public void setArtCollectionName(String artCollectionName) {
        this.artCollectionName = artCollectionName;
    }
}
