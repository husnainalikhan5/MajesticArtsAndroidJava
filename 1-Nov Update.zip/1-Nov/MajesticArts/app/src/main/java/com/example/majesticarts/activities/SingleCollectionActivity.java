package com.example.majesticarts.activities;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.majesticarts.R;
import com.example.majesticarts.adapters.TrendingCategoryAdapter;
import com.example.majesticarts.models.PostDataModel;
import com.example.majesticarts.models.PostResponseModel;
import com.example.majesticarts.network.GetDataService;
import com.example.majesticarts.network.RetrofitClientInstance;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SingleCollectionActivity extends AppCompatActivity {
    private RecyclerView recylerView_SingleCollection;
    private RecyclerView.Adapter<TrendingCategoryAdapter.ViewHolder> adapter;
    GetDataService service;
    ProgressDialog progressDialog;
    String collectionName;
    TextView text_CollectionName;
    ImageView back_ic;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_collection);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setTopStatusBarColor();
        }
        back_ic = findViewById(R.id.back_ic);
        back_ic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        collectionName = getIntent().getStringExtra("collectionName");
        progressDialog = new ProgressDialog(SingleCollectionActivity.this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();
        service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        text_CollectionName = findViewById(R.id.text_CollectionName);
        text_CollectionName.setText(collectionName);
        Toast.makeText(getApplicationContext(),"Collection Name : " + collectionName, Toast.LENGTH_LONG).show();
        recylerView_SingleCollection = findViewById(R.id.recylerView_SingleCollection);
        loadCollectionPosts();
    }

    private void loadCollectionPosts() {

        Call<PostResponseModel> call = service.getPostsByCollection("5", collectionName);
        call.enqueue(new Callback<PostResponseModel>() {
            @Override
            public void onResponse(Call<PostResponseModel> call, Response<PostResponseModel> response) {
                progressDialog.dismiss();
                assert response.body() != null;
                int status  = response.body().getStatus();
                if (!String.valueOf(status).isEmpty() && status == 200){
                    List<PostDataModel> dataList = response.body().getData();
                    if (dataList == null){
                        Toast.makeText(getApplicationContext(), "No Record Found", Toast.LENGTH_LONG).show();
                    }
                    else {
                        showCollectionsPosts(recylerView_SingleCollection, dataList);
                    }


                }
                else if (!String.valueOf(status).isEmpty() && status == 400){
                    Toast.makeText(getApplicationContext(), response.body().getMessage()  + "Failed", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<PostResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
            }
        });
    }


    public void showCollectionsPosts(RecyclerView recyclerView,   List<PostDataModel> listItems){
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(gridLayoutManager);
        adapter = new TrendingCategoryAdapter(listItems, this);
        recyclerView.setAdapter(adapter);
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void setTopStatusBarColor(){
        Window window = SingleCollectionActivity.this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(SingleCollectionActivity.this,R.color.color_cloud_brust));
    }

}