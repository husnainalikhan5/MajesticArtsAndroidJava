package com.example.majesticarts.fragments;

import android.app.Activity;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.majesticarts.R;
import com.example.majesticarts.adapters.ForYouArtCollectionAdapter;
import com.example.majesticarts.adapters.TrendingCategoryAdapter;
import com.example.majesticarts.models.CollectionsDataModel;
import com.example.majesticarts.models.CollectionsResponseModel;
import com.example.majesticarts.models.PostDataModel;
import com.example.majesticarts.models.PostResponseModel;
import com.example.majesticarts.network.GetDataService;
import com.example.majesticarts.network.RetrofitClientInstance;
import com.example.majesticarts.utilities.Utilities;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ForYouFragment extends Fragment {
    private RecyclerView recylerView_TrendingPost, recylerView_artCollections;
    private RecyclerView.Adapter adapter;;
    GetDataService service;
    String userId;
    Activity activity;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_for_you, container, false);
        activity = getActivity();
        userId = String.valueOf(Utilities.getInt(activity, "userId"));
        service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        recylerView_TrendingPost = view.findViewById(R.id.recylerView_Trending);
        loadTrendingPosts();
        recylerView_artCollections = view.findViewById(R.id.recylerView_artCollections);
        loadTrendingCollection();
        return view;
    }
    private void loadTrendingPosts() {

        Call<PostResponseModel> call = service.trendingPosts(userId);

        call.enqueue(new Callback<PostResponseModel>() {
            @Override
            public void onResponse(Call<PostResponseModel> call, Response<PostResponseModel> response) {
                assert response.body() != null;
                int status = 400;
                if ( response.body() != null){
                    status = response.body().getStatus();
                }
                if (!String.valueOf(status).isEmpty() && status == 200){
                    List dataList = response.body().getData();
                    if (dataList == null && activity != null){
                        Toast.makeText(activity, "No Record Found", Toast.LENGTH_LONG).show();
                    }
                    else {
                        showTrendingCategory(recylerView_TrendingPost, dataList);
                    }

                }
                else if (!String.valueOf(status).isEmpty() && status == 400 && activity != null){
                    Toast.makeText(activity, response.body().getMessage()  + "Failed", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<PostResponseModel> call, Throwable t) {
                if (activity != null){
                    Toast.makeText(activity, t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
                }

            }
        });
    }
    public void showTrendingCategory(RecyclerView recyclerView, List<PostDataModel> PostDataModelList){
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        adapter = new TrendingCategoryAdapter(PostDataModelList, getContext());
        recyclerView.setAdapter(adapter);
    }
    private void loadTrendingCollection() {

        Call<CollectionsResponseModel> call = service.getTrendingCollection();

        call.enqueue(new Callback<CollectionsResponseModel>() {
            @Override
            public void onResponse(Call<CollectionsResponseModel> call, Response<CollectionsResponseModel> response) {
                assert response.body() != null;
                int status  = response.body().getStatus();
                if (!String.valueOf(status).isEmpty() && status == 200){
                    List dataList = response.body().getData();
                    if (dataList == null && activity != null){
                        Toast.makeText(activity, "No Record Found", Toast.LENGTH_LONG).show();
                    }
                    else {
                        showForYouCollection(recylerView_artCollections, dataList);
                    }
                }
                else if (!String.valueOf(status).isEmpty() && status == 400 && activity !=null){
                    Toast.makeText(activity, response.body().getMessage()  + "Failed", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<CollectionsResponseModel> call, Throwable t) {
                if (activity !=null){
                    Toast.makeText(activity, t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
                }

            }
        });
    }
    public void showForYouCollection(RecyclerView recyclerView,  List<CollectionsDataModel> collectionsDataModelList){
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new ForYouArtCollectionAdapter(collectionsDataModelList, getContext());
        recyclerView.setAdapter(adapter);
    }

}