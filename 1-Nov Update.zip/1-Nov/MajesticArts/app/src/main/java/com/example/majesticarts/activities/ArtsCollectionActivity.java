package com.example.majesticarts.activities;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.majesticarts.R;
import com.example.majesticarts.adapters.ForYouArtCollectionAdapter;
import com.example.majesticarts.adapters.OurCollectionAdapter;
import com.example.majesticarts.models.AuthResponseModel;
import com.example.majesticarts.models.CollectionsDataModel;
import com.example.majesticarts.models.CollectionsResponseModel;
import com.example.majesticarts.models.ForYouArtCollectionModel;
import com.example.majesticarts.models.TrendingModel;
import com.example.majesticarts.network.GetDataService;
import com.example.majesticarts.network.RetrofitClientInstance;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ArtsCollectionActivity extends AppCompatActivity {
    GetDataService service;
    ProgressDialog progressDialog;
    private RecyclerView recylerView_artCollections;
    private RecyclerView.Adapter adapter;
    ImageView back_ic;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arts_collection);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setTopStatusBarColor();
        }
        back_ic = findViewById(R.id.back_ic);
        back_ic.setOnClickListener(v -> onBackPressed());


        recylerView_artCollections = findViewById(R.id.recylerView_artCollections);
        progressDialog = new ProgressDialog(ArtsCollectionActivity.this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();
        service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        LoadAllCollections();
    }

    private void LoadAllCollections() {

        Call<CollectionsResponseModel> call = service.getAllCollections();

        call.enqueue(new Callback<CollectionsResponseModel>() {
            @Override
            public void onResponse(Call<CollectionsResponseModel> call, Response<CollectionsResponseModel> response) {
                progressDialog.dismiss();
                assert response.body() != null;
                int status  = response.body().getStatus();
                if (!String.valueOf(status).isEmpty() && status == 200){
                    List dataList = response.body().getData();
                    if (dataList == null){
                        Toast.makeText(getApplicationContext(), "No Record Found", Toast.LENGTH_LONG).show();
                    }
                    else {
                        showTrendingCollection(recylerView_artCollections, dataList);
                    }
                }
                else if (!String.valueOf(status).isEmpty() && status == 400){
                    Toast.makeText(getApplicationContext(), response.body().getMessage()  + "Failed", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<CollectionsResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void showTrendingCollection(RecyclerView recyclerView,  List<CollectionsDataModel> collectionsDataModelList){
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new OurCollectionAdapter(collectionsDataModelList,this);
        recyclerView.setAdapter(adapter);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void setTopStatusBarColor(){
        Window window = ArtsCollectionActivity.this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(ArtsCollectionActivity.this,R.color.color_cloud_brust));
    }
}