package com.example.majesticarts.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CollectionsResponseModel {
    @SerializedName("status")
    private int status;
    @SerializedName("message")
    private String message;
    @SerializedName("data")
    private List<CollectionsDataModel> data;

    public CollectionsResponseModel() {
    }

    public CollectionsResponseModel(int status, String message, List<CollectionsDataModel> data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<CollectionsDataModel> getData() {
        return data;
    }

    public void setData(List<CollectionsDataModel> data) {
        this.data = data;
    }
}
