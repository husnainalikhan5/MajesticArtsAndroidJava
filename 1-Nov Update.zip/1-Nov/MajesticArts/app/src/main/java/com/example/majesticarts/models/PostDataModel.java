package com.example.majesticarts.models;

import com.google.gson.annotations.SerializedName;

public class PostDataModel {
    @SerializedName("id")
    private int id;
    @SerializedName("trending")
    private String trending;
    @SerializedName("title")
    private String title;
    @SerializedName("subtitle")
    private String subtitle;
    @SerializedName("collection_name")
    private String collection_name;
    @SerializedName("description")
    private String description;
    @SerializedName("caption_image")
    private String caption_image;
    @SerializedName("image1")
    private String image1;
    @SerializedName("image2")
    private String image2;
    @SerializedName("image3")
    private String image3;
    @SerializedName("image4")
    private String image4;
    @SerializedName("image5")
    private String image5;
    @SerializedName("favrte_routine")
    private String favrte_routine;

    public PostDataModel() {
    }

    public PostDataModel(int id, String trending, String title, String subtitle, String collection_name, String description, String caption_image, String image1, String image2, String image3, String image4, String image5, String favrte_routine) {
        this.id = id;
        this.trending = trending;
        this.title = title;
        this.subtitle = subtitle;
        this.collection_name = collection_name;
        this.description = description;
        this.caption_image = caption_image;
        this.image1 = image1;
        this.image2 = image2;
        this.image3 = image3;
        this.image4 = image4;
        this.image5 = image5;
        this.favrte_routine = favrte_routine;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTrending() {
        return trending;
    }

    public void setTrending(String trending) {
        this.trending = trending;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getCollection_name() {
        return collection_name;
    }

    public void setCollection_name(String collection_name) {
        this.collection_name = collection_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCaption_image() {
        return caption_image;
    }

    public void setCaption_image(String caption_image) {
        this.caption_image = caption_image;
    }

    public String getImage1() {
        return image1;
    }

    public void setImage1(String image1) {
        this.image1 = image1;
    }

    public String getImage2() {
        return image2;
    }

    public void setImage2(String image2) {
        this.image2 = image2;
    }

    public String getImage3() {
        return image3;
    }

    public void setImage3(String image3) {
        this.image3 = image3;
    }

    public String getImage4() {
        return image4;
    }

    public void setImage4(String image4) {
        this.image4 = image4;
    }

    public String getImage5() {
        return image5;
    }

    public void setImage5(String image5) {
        this.image5 = image5;
    }

    public String getFavrte_routine() {
        return favrte_routine;
    }

    public void setFavrte_routine(String favrte_routine) {
        this.favrte_routine = favrte_routine;
    }
}
