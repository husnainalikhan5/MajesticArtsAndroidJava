package com.example.majesticarts.activities;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.example.majesticarts.R;
import com.example.majesticarts.adapters.HomeTabsAdapter;
import com.example.majesticarts.adapters.LoginRegisterTabsAdapter;
import com.google.android.material.tabs.TabLayout;

public class LoginActivityRegister extends AppCompatActivity {
    TabLayout tabLayout;
    ViewPager viewPagerLoginRegister;
    ImageView imgLogo;
    Animation fade_in;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_register);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setTopStatusBarColor();
        }
        tabLayout = findViewById(R.id.tabLayout);
        viewPagerLoginRegister = findViewById(R.id.viewPagerLoginRegister);
        imgLogo = findViewById(R.id.logo);
        fade_in = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in);

        final LoginRegisterTabsAdapter myPagerAdapter = new LoginRegisterTabsAdapter(getSupportFragmentManager());
        viewPagerLoginRegister.setAdapter(myPagerAdapter);
        tabLayout.setupWithViewPager(viewPagerLoginRegister);
        showVericalLinesSeprator(tabLayout);
    }



    private void showVericalLinesSeprator(TabLayout tabLayout){
        View root = tabLayout.getChildAt(0);
        if (root instanceof LinearLayout) {
            ((LinearLayout) root).setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
            GradientDrawable drawable = new GradientDrawable();
            drawable.setColor(getResources().getColor(R.color.colorCloudBurst));
            drawable.setSize(5, 1);
            ((LinearLayout) root).setDividerPadding(10);
            ((LinearLayout) root).setDividerDrawable(drawable);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        imgLogo.setTranslationY(0);
        imgLogo.animate().translationYBy(-400).setDuration(1000);
        imgLogo.startAnimation(fade_in);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void setTopStatusBarColor(){
        Window window = LoginActivityRegister.this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(LoginActivityRegister.this,R.color.color_cloud_brust));
    }
}