package com.example.majesticarts.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.majesticarts.R;
import com.example.majesticarts.activities.SingleCollectionActivity;
import com.example.majesticarts.models.CollectionsDataModel;


import java.util.List;

public class ForYouArtCollectionAdapter extends RecyclerView.Adapter<ForYouArtCollectionAdapter.ViewHolder> {
    List<CollectionsDataModel> listItems;
    Context context;

    public ForYouArtCollectionAdapter(List<CollectionsDataModel> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.single_foryou_art_collection, parent, false);
        return new ForYouArtCollectionAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CollectionsDataModel listItem = listItems.get(position);
        Glide.with(holder.itemView)
                .load(listItem.getImage())
                .fitCenter()
                .into(holder.artCollectionImage);
        holder.artCollectionName.setText(listItem.getName());
        holder.btn_Discover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = new Intent(v.getContext(), SingleCollectionActivity.class);
                intent.putExtra("collectionName", listItem.getName());
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView artCollectionImage;
        public TextView artCollectionName;
        public Button btn_Discover;
        public ViewHolder(@NonNull View view) {
            super(view);

            artCollectionImage = view.findViewById(R.id.artCollectionImage);
            artCollectionName = view.findViewById(R.id.text_CollectionName);
            btn_Discover = view.findViewById(R.id.btn_Discover);

        }
    }
}
