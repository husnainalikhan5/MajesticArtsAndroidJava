package com.example.majesticarts.models;

import com.google.gson.annotations.SerializedName;

public class CollectionsDataModel {
    @SerializedName("id")
    private int id;
    @SerializedName("tranding")
    private String tranding;
    @SerializedName("name")
    private String name;
    @SerializedName("image")
    private String image;

    public CollectionsDataModel() {
    }

    public CollectionsDataModel(int id, String tranding, String name, String image) {
        this.id = id;
        this.tranding = tranding;
        this.name = name;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTranding() {
        return tranding;
    }

    public void setTranding(String tranding) {
        this.tranding = tranding;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
