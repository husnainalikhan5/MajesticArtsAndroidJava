package com.example.majesticarts.network;

import com.example.majesticarts.models.AuthResponseModel;
import com.example.majesticarts.models.CollectionsResponseModel;
import com.example.majesticarts.models.PostResponseModel;
import com.example.majesticarts.models.AddFavouriteResponseModel;
import com.example.majesticarts.models.UpdateMobileNumberModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface GetDataService {
    @Headers({
            "Accept: application/json",
    })
    @FormUrlEncoded
    @POST("login")
    Call<AuthResponseModel> loginUser(@Field("email") String email,
                                      @Field("password") String password);

    @Headers({
            "Accept: application/json",
    })
    @FormUrlEncoded
    @POST("signup")
    Call<AuthResponseModel> registerUser(@Field("f_name") String f_name,
                                         @Field("l_name") String l_name,
                                         @Field("email") String email,
                                         @Field("password") String password,
                                         @Field("phone") String phone);

    @Headers({
            "Accept: application/json",
    })
    @FormUrlEncoded
    @POST("trending_posts")
    Call<PostResponseModel> trendingPosts(@Field("user_id") String user_id);

    @Headers({
            "Accept: application/json",
    })
    @FormUrlEncoded
    @POST("collection_posts")
    Call<PostResponseModel> getAllPosts(@Field("user_id") String user_id);

    @Headers({
            "Accept: application/json",
    })
    @FormUrlEncoded
    @POST("get_favroute")
    Call<PostResponseModel> getUserFavourites(@Field("user_id") String user_id);

    @Headers({
            "Accept: application/json",
    })
    @FormUrlEncoded
    @POST("post_by_collections")
    Call<PostResponseModel> getPostsByCollection(@Field("user_id") String user_id,
                                                 @Field("collection_name") String collection_name
    );

    @FormUrlEncoded
    @POST("reset_password")
    Call<AuthResponseModel> resetUserPassword(@Field("user_id") String user_id,
                                              @Field("password") String password,
                                              @Field("conf_password") String conf_password
    );

    @FormUrlEncoded
    @POST("update_phone")
    Call<UpdateMobileNumberModel> updateMobileNumber(@Field("user_id") String user_id,
                                                     @Field("phone") String phone
    );

    @FormUrlEncoded
    @POST("add_favroute")
    Call<AddFavouriteResponseModel> add_Favourites(@Field("user_id") String user_id,
                                                   @Field("post_id") String post_id
                                             );
    @FormUrlEncoded
    @POST("qoutation")
    Call<AuthResponseModel> getQuotation(@Field("f_name") String f_name,
                                                 @Field("l_name") String l_name,
                                                 @Field("email") String email,
                                                 @Field("phone") String phone,
                                                 @Field("post_id") String post_id,
                                                 @Field("post_title") String post_title);

    @GET("collections")
    Call<CollectionsResponseModel> getAllCollections();

    @GET("tranding_collections")
    Call<CollectionsResponseModel> getTrendingCollection();
}
