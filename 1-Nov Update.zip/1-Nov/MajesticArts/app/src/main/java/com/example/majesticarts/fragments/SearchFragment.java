package com.example.majesticarts.fragments;

import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.majesticarts.R;
import com.example.majesticarts.adapters.PostsSearchAdapter;
import com.example.majesticarts.models.PostDataModel;
import com.example.majesticarts.models.PostResponseModel;
import com.example.majesticarts.network.GetDataService;
import com.example.majesticarts.network.RetrofitClientInstance;
import com.example.majesticarts.utilities.Utilities;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SearchFragment extends Fragment {
    private RecyclerView recylerView_AllCollections;
    private PostsSearchAdapter postsSearchAdapter;
    GetDataService service;
    String userId;
    SearchView searchView;
    private List<PostDataModel> postDataModelList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_search, container, false);
        userId = String.valueOf(Utilities.getInt(getContext(), "userId"));
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = view.findViewById(R.id.edit_SearchView);
        postsSearchAdapter = new PostsSearchAdapter();
        postDataModelList = new ArrayList<>();
        //Working with SearchView
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                postsSearchAdapter.getFilter().filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                postsSearchAdapter.getFilter().filter(newText);
                return false;
            }
        });

        service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);
        recylerView_AllCollections = view.findViewById(R.id.recylerView_AllCollections);
        loadAllPosts();
        return view;
    }





    private void loadAllPosts() {

        Call<PostResponseModel> call = service.getAllPosts(userId);
        call.enqueue(new Callback<PostResponseModel>() {
            @Override
            public void onResponse(Call<PostResponseModel> call, Response<PostResponseModel> response) {
                assert response.body() != null;
                int status  = response.body().getStatus();
                if (!String.valueOf(status).isEmpty() && status == 200){
                    postDataModelList = response.body().getData();
                    if (postDataModelList == null){
                        Toast.makeText(getContext(), "No Record Found", Toast.LENGTH_LONG).show();
                    }
                    else {
                        showAllPosts(recylerView_AllCollections, postDataModelList);
                    }
                }
                else if (!String.valueOf(status).isEmpty() && status == 400){
                    Toast.makeText(getContext(), response.body().getMessage()  + "Failed", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<PostResponseModel> call, Throwable t) {
                Toast.makeText(getContext(), t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
            }
        });
    }



    public void showAllPosts(RecyclerView recyclerView, List<PostDataModel> PostDataModelList){
        recyclerView.setHasFixedSize(true);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(),2);
        recyclerView.setLayoutManager(gridLayoutManager);
        postsSearchAdapter.setSearchItems(getContext(), PostDataModelList);
        recyclerView.setAdapter(postsSearchAdapter);
    }
}