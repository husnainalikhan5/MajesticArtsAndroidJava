package com.example.majesticarts.fragments;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.majesticarts.R;
import com.example.majesticarts.activities.MainActivity;
import com.example.majesticarts.models.AuthResponseModel;
import com.example.majesticarts.network.GetDataService;
import com.example.majesticarts.network.RetrofitClientInstance;
import com.example.majesticarts.utilities.Utilities;
import com.google.android.material.snackbar.Snackbar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class LoginFragment extends Fragment {
    GetDataService service;
    ProgressDialog progressDialog;
    EditText edit_Email,edit_Password;
    Button btn_Login;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_login, container, false);
        btn_Login = view.findViewById(R.id.btn_Login);
        edit_Email = view.findViewById(R.id.edit_Email);
        edit_Password = view.findViewById(R.id.edit_Password);
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Singing In....");
        service = RetrofitClientInstance.getRetrofitInstance().create(GetDataService.class);

        btn_Login.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onClick(View v) {
                progressDialog.show();
                String userEmail = edit_Email.getText().toString();
                String userPassword = edit_Password.getText().toString();
                Utilities.hideKeyboard(v, getContext());
                if (userEmail.isEmpty() || userPassword.isEmpty())
                {
                    progressDialog.dismiss();

                    Snackbar.make(view, "Please Add Missing Fields", Snackbar.LENGTH_LONG)
                            .setBackgroundTint(R.color.color_cloud_brust).setBackgroundTintMode(PorterDuff.Mode.DARKEN).show();
                }
                else {
                    sendLoginRequest(userEmail, userPassword);
                }
            }
        });
        return view;
    }

    private void sendLoginRequest(String email, String password) {

        Call<AuthResponseModel> call = service.loginUser( email,password);

        call.enqueue(new Callback<AuthResponseModel>() {
            @Override
            public void onResponse(Call<AuthResponseModel> call, Response<AuthResponseModel> response) {
                progressDialog.dismiss();
                assert response.body() != null;
                int status  = response.body().getStatus();
                if (!String.valueOf(status).isEmpty() && status == 200){
                    Toast.makeText(getActivity(), response.body().getMessage() , Toast.LENGTH_LONG).show();
                    int userId = response.body().getData().getId();
                    String userEmail = response.body().getData().getEmail();
                    String userFName = response.body().getData().getF_name();
                    String userLName = response.body().getData().getL_name();
                    String userPhone =  response.body().getData().getPhone();
                    Utilities.saveInt(getContext(),"userId", userId);
                    Utilities.saveString(getContext(), "userEmail" , userEmail);
                    Utilities.saveString(getContext(), "userName" , userFName + " " + userLName);
                    Utilities.saveString(getContext(),"login_status","yes");
                    Utilities.saveString(getContext(), "userFName", userFName);
                    Utilities.saveString(getContext(), "userLName", userLName);
                    Utilities.saveString(getContext(), "userPhone", userPhone);
                    Intent mainIntent =  new Intent(getActivity(), MainActivity.class);
                    startActivity(mainIntent);
                    getActivity().finish();
                }
                else if (!String.valueOf(status).isEmpty() && status == 400){
                    Toast.makeText(getActivity(), response.body().getMessage()  + "Failed", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<AuthResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), t.getMessage() + "Not Called", Toast.LENGTH_LONG).show();
            }
        });
    }
}