package com.example.majesticarts.adapters;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentStatePagerAdapter;
import com.example.majesticarts.fragments.FavouratesFragment;
import com.example.majesticarts.fragments.ForYouFragment;
import com.example.majesticarts.fragments.SearchFragment;

public class HomeTabsAdapter extends FragmentStatePagerAdapter {

    public HomeTabsAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new ForYouFragment();
            case 1:
                return new SearchFragment();
            case 2:
                return new FavouratesFragment();
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "For you";
            case 1:
                return "Search";
            case 2:
                return "Favourites";

            default:
                return null;
        }
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return super.getItemPosition(object);
    }
}
