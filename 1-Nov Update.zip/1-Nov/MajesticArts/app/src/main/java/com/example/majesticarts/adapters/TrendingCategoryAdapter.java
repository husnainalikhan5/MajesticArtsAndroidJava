package com.example.majesticarts.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.majesticarts.R;
import com.example.majesticarts.activities.SingleItemActivity;
import com.example.majesticarts.models.PostDataModel;
import java.util.List;

public class TrendingCategoryAdapter extends RecyclerView.Adapter<TrendingCategoryAdapter.ViewHolder>{

    List<PostDataModel> listItems;
    Context context;

    public TrendingCategoryAdapter(List<PostDataModel> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.single_trending_item, parent, false);
        return new TrendingCategoryAdapter.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        PostDataModel listItem = listItems.get(position);
        holder.text_Courtesy.setText(listItem.getSubtitle());
        holder.text_Detail.setText(listItem.getTitle());
        Glide.with(holder.itemView)
                .load(listItem.getCaption_image())
                .fitCenter()
                .into(holder.trending_Image);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(holder.itemView.getContext(), SingleItemActivity.class);
                mainIntent.putExtra("postId", listItem.getId());
                mainIntent.putExtra("postName", listItem.getTitle());
                mainIntent.putExtra("postDetail", listItem.getDescription());
                mainIntent.putExtra("image1", listItem.getImage1());
                mainIntent.putExtra("image2", listItem.getImage2());
                mainIntent.putExtra("image3", listItem.getImage3());
                mainIntent.putExtra("image4", listItem.getImage4());
                mainIntent.putExtra("image5", listItem.getImage5());
                mainIntent.putExtra("favourite_status", listItem.getFavrte_routine());
                holder.itemView.getContext().startActivity(mainIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }



    public class ViewHolder extends  RecyclerView.ViewHolder{
        public ImageView trending_Image;
        public TextView text_Detail, text_Courtesy;
        public ViewHolder(@NonNull View view) {
            super(view);

            trending_Image = view.findViewById(R.id.trending_Image);
            text_Detail = view.findViewById(R.id.trending_Detail);
            text_Courtesy = view.findViewById(R.id.trending_courtesy);
        }
    }


}
